package com.example.practical_08;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private RadioGroup courseRadioGroup;
    private TextView ticValueTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        courseRadioGroup = findViewById(R.id.courseRadioGroup);
        ticValueTextView = findViewById(R.id.ticValueTextView);

        courseRadioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            String tic = getTicForCourse(checkedId);
            ticValueTextView.setText(tic);
        });
    }

    private String getTicForCourse(int radioButtonId) {
        if (radioButtonId == R.id.radioWebDev) {
            return "3";
        } else if (radioButtonId == R.id.radioMobileDev) {
            return "4";
        } else if (radioButtonId == R.id.radioAI) {
            return "5";
        }
        return "--";
    }
}

