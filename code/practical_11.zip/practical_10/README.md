# Login and Registration App

A simple Android login and registration application with SQLite database integration.

## Features

- User Registration with validation
- User Login with credential verification
- SQLite database for storing user credentials
- Welcome screen with personalized greeting
- Toast message showing "Welcome [Username]" on successful login

## Components

### Activities
- **LoginActivity**: Main entry point for user login
- **RegisterActivity**: New user registration
- **WelcomeActivity**: Displayed after successful login

### Database
- **DatabaseHelper**: SQLite database helper for user management

## How to Use

1. Launch the app (opens LoginActivity)
2. For new users: Click "Don't have an account? Register"
3. Enter username, password, and confirm password
4. Click "Register" to create account
5. Return to login screen and enter credentials
6. Upon successful login, see "Welcome [Username]" toast message
7. Welcome screen displays with personalized greeting

## Build and Run

```bash
.\gradlew.bat build
```

Then run the app on an Android device or emulator through Android Studio.
