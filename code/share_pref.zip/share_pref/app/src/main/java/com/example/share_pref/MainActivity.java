package com.example.share_pref;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editName;
    TextView textDisplay;
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pref = getSharedPreferences("MyPref", MODE_PRIVATE);
        editName = findViewById(R.id.editName);
        textDisplay = findViewById(R.id.textDisplay);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnClear = findViewById(R.id.btnClear);

        textDisplay.setText(pref.getString("name", "No data"));

        btnSave.setOnClickListener(v -> {
            String name = editName.getText().toString();
            pref.edit().putString("name", name).apply();
            textDisplay.setText(name);
            Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
        });

        btnClear.setOnClickListener(v -> {
            pref.edit().clear().apply();
            editName.setText("");
            textDisplay.setText("No data");
            Toast.makeText(this, "Cleared!", Toast.LENGTH_SHORT).show();
        });
    }
}
