package com.example.api_intigration;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout container = findViewById(R.id.container);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService api = retrofit.create(ApiService.class);
        api.getUsers().enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<User> users = response.body();
                    int count = Math.min(5, users.size());
                    for (int i = 0; i < count; i++) {
                        addUserCard(container, users.get(i));
                    }
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void addUserCard(LinearLayout container, User user) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setPadding(40, 40, 40, 40);
        card.setBackgroundColor(0xFFF5F5F5);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, 24);
        card.setLayoutParams(cardParams);

        ImageView img = new ImageView(this);
        img.setLayoutParams(new LinearLayout.LayoutParams(180, 180));
        Glide.with(this).load("https://i.pravatar.cc/150?img=" + user.id).circleCrop().into(img);

        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        textLayout.setPadding(40, 0, 0, 0);

        TextView name = new TextView(this);
        name.setText(user.name);
        name.setTextSize(20);
        name.setTextColor(0xFF000000);
        name.setPadding(0, 0, 0, 12);

        TextView email = new TextView(this);
        email.setText(user.email);
        email.setTextSize(16);
        email.setTextColor(0xFF666666);

        textLayout.addView(name);
        textLayout.addView(email);
        card.addView(img);
        card.addView(textLayout);
        container.addView(card);
    }
}