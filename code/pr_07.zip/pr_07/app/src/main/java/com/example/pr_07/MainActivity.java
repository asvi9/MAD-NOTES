package com.example.pr_07;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextBillAmount;
    private RadioGroup radioGroupDiscount;
    private RadioButton radioButton10, radioButton15, radioButton20;
    private Button buttonCalculate;
    private TextView textViewOriginalAmount, textViewDiscountAmount, textViewFinalAmount;

    private DecimalFormat decimalFormat = new DecimalFormat("#0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeViews();
        setupClickListeners();
    }

    private void initializeViews() {
        editTextBillAmount = findViewById(R.id.editTextBillAmount);
        radioGroupDiscount = findViewById(R.id.radioGroupDiscount);
        radioButton10 = findViewById(R.id.radioButton10);
        radioButton15 = findViewById(R.id.radioButton15);
        radioButton20 = findViewById(R.id.radioButton20);
        buttonCalculate = findViewById(R.id.buttonCalculate);
        textViewOriginalAmount = findViewById(R.id.textViewOriginalAmount);
        textViewDiscountAmount = findViewById(R.id.textViewDiscountAmount);
        textViewFinalAmount = findViewById(R.id.textViewFinalAmount);
    }

    private void setupClickListeners() {
        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateDiscount();
            }
        });

        radioGroupDiscount.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (!editTextBillAmount.getText().toString().trim().isEmpty()) {
                    calculateDiscount();
                }
            }
        });
    }

    private void calculateDiscount() {
        String billAmountStr = editTextBillAmount.getText().toString().trim();

        if (billAmountStr.isEmpty()) {
            Toast.makeText(this, "Please enter the bill amount", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double billAmount = Double.parseDouble(billAmountStr);

            if (billAmount <= 0) {
                Toast.makeText(this, "Please enter a valid amount greater than 0", Toast.LENGTH_SHORT).show();
                return;
            }

            double discountPercentage = getSelectedDiscountPercentage();
            double discountAmount = billAmount * (discountPercentage / 100);
            double finalAmount = billAmount - discountAmount;

            textViewOriginalAmount.setText("Original Amount: $" + decimalFormat.format(billAmount));
            textViewDiscountAmount.setText("Discount Amount (" + (int)discountPercentage + "%): $" + decimalFormat.format(discountAmount));
            textViewFinalAmount.setText("Final Amount: $" + decimalFormat.format(finalAmount));

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
        }
    }

    private double getSelectedDiscountPercentage() {
        int selectedId = radioGroupDiscount.getCheckedRadioButtonId();

        if (selectedId == R.id.radioButton10) {
            return 10.0;
        } else if (selectedId == R.id.radioButton15) {
            return 15.0;
        } else if (selectedId == R.id.radioButton20) {
            return 20.0;
        }

        return 10.0;
    }
}