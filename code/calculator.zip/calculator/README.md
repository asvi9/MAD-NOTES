# Professional Calculator App

A sleek, modern Android calculator app with professional UI design and smooth animations.

## ✨ Features

### Core Functionality
- **Basic Operations**: Addition (+), Subtraction (−), Multiplication (×), Division (÷)
- **Decimal Support**: Handle decimal numbers with precision
- **Clear Function**: AC (All Clear) to reset calculator completely
- **Backspace**: Remove last entered digit with ⌫ button
- **Error Handling**: Division by zero protection with user feedback
- **Continuous Calculations**: Chain operations seamlessly

### Professional UI Design
- **Dark Theme**: Modern dark interface with gradient backgrounds
- **Dual Display**: 
  - Primary display for current numbers and results
  - Secondary display showing ongoing operations
- **Color-Coded Buttons**:
  - **Gray**: Number buttons (0-9, decimal point)
  - **Orange**: Operation buttons (+, −, ×, ÷, =)
  - **Light Gray**: Utility buttons (AC, ⌫)
- **Material Design**: Rounded corners, proper spacing, and elevation
- **Responsive Text**: Auto-sizing text that adapts to content length
- **Smooth Animations**: Button press feedback and transitions

## 🎨 Design Elements

- **Gradient Background**: Subtle dark gradient for depth
- **Professional Typography**: Clean, readable fonts with proper hierarchy
- **Button Styling**: Consistent 72dp height with 20dp corner radius
- **Proper Spacing**: 6dp margins for optimal touch targets
- **Visual Feedback**: Button press states and ripple effects

## 📱 How to Use

1. **Numbers**: Tap number buttons (0-9) to enter numbers
2. **Operations**: Tap operation buttons (+, −, ×, ÷) to select operation
3. **Equals**: Tap "=" to calculate result
4. **All Clear**: Tap "AC" to clear everything and start over
5. **Backspace**: Tap "⌫" to remove last digit
6. **Decimal**: Tap "." to add decimal point
7. **Chain Operations**: Continue calculations without clearing

## 🛠 Technical Details

- **Language**: Java
- **Platform**: Android (API 34+)
- **UI Framework**: Material Design 3 Components
- **Layout**: LinearLayout with responsive button grid
- **Theme**: Dark theme with professional color scheme
- **Architecture**: Clean separation of UI and business logic

## 🚀 Building the App

```bash
# Clean build
./gradlew clean

# Build debug APK
./gradlew assembleDebug

# Build and run tests
./gradlew build

# Install on connected device
./gradlew installDebug
```

## 📁 App Structure

- `MainActivity.java` - Calculator logic, UI handling, and state management
- `activity_main.xml` - Professional layout with dual display and button grid
- `themes.xml` - Custom styling with multiple button types and dark theme
- `drawable/` - Gradient backgrounds and button selectors for animations

## 🎯 Key Improvements

- **Professional Appearance**: Dark theme with carefully chosen colors
- **Better UX**: Secondary display shows current operation context
- **Improved Typography**: Better font choices and sizing
- **Enhanced Feedback**: Visual button press states
- **Consistent Design**: Unified color scheme and spacing
- **Error Handling**: Graceful handling of edge cases

The calculator provides a premium user experience with professional-grade design and smooth functionality.