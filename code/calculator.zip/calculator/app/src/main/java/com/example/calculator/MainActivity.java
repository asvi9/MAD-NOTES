package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvDisplay;
    private TextView tvSecondaryDisplay;
    private String currentNumber = "";
    private String operator = "";
    private String firstNumber = "";
    private boolean isNewOperation = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeViews();
        setClickListeners();
    }

    private void initializeViews() {
        tvDisplay = findViewById(R.id.tvDisplay);
        tvSecondaryDisplay = findViewById(R.id.tvSecondaryDisplay);
    }

    private void setClickListeners() {
        findViewById(R.id.btn0).setOnClickListener(this);
        findViewById(R.id.btn1).setOnClickListener(this);
        findViewById(R.id.btn2).setOnClickListener(this);
        findViewById(R.id.btn3).setOnClickListener(this);
        findViewById(R.id.btn4).setOnClickListener(this);
        findViewById(R.id.btn5).setOnClickListener(this);
        findViewById(R.id.btn6).setOnClickListener(this);
        findViewById(R.id.btn7).setOnClickListener(this);
        findViewById(R.id.btn8).setOnClickListener(this);
        findViewById(R.id.btn9).setOnClickListener(this);

        findViewById(R.id.btnAdd).setOnClickListener(this);
        findViewById(R.id.btnSubtract).setOnClickListener(this);
        findViewById(R.id.btnMultiply).setOnClickListener(this);
        findViewById(R.id.btnDivide).setOnClickListener(this);
        findViewById(R.id.btnEquals).setOnClickListener(this);

        findViewById(R.id.btnClear).setOnClickListener(this);
        findViewById(R.id.btnBackspace).setOnClickListener(this);
        findViewById(R.id.btnDecimal).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Button button = (Button) v;
        String buttonText = button.getText().toString();

        int id = v.getId();

        if (id == R.id.btn0 || id == R.id.btn1 || id == R.id.btn2 || id == R.id.btn3 ||
            id == R.id.btn4 || id == R.id.btn5 || id == R.id.btn6 || id == R.id.btn7 ||
            id == R.id.btn8 || id == R.id.btn9) {
            handleNumberInput(buttonText);
        } else if (id == R.id.btnDecimal) {
            handleDecimalInput();
        } else if (id == R.id.btnAdd || id == R.id.btnSubtract || id == R.id.btnMultiply || id == R.id.btnDivide) {
            handleOperatorInput(buttonText);
        } else if (id == R.id.btnEquals) {
            handleEqualsInput();
        } else if (id == R.id.btnClear) {
            handleClearInput();
        } else if (id == R.id.btnBackspace) {
            handleBackspaceInput();
        }
    }

    private void handleNumberInput(String number) {
        if (isNewOperation) {
            currentNumber = number;
            isNewOperation = false;
        } else {
            if (currentNumber.equals("0")) {
                currentNumber = number;
            } else {
                currentNumber += number;
            }
        }
        updateDisplay(currentNumber);
    }

    private void handleDecimalInput() {
        if (isNewOperation) {
            currentNumber = "0.";
            isNewOperation = false;
        } else if (!currentNumber.contains(".")) {
            if (currentNumber.isEmpty()) {
                currentNumber = "0.";
            } else {
                currentNumber += ".";
            }
        }
        updateDisplay(currentNumber);
    }

    private void handleOperatorInput(String op) {
        if (!currentNumber.isEmpty()) {
            if (!firstNumber.isEmpty() && !operator.isEmpty()) {
                handleEqualsInput();
                firstNumber = currentNumber;
            } else {
                firstNumber = currentNumber;
            }
            
            String displayOp = op;
            switch (op) {
                case "×":
                    operator = "*";
                    break;
                case "÷":
                    operator = "/";
                    break;
                case "−":
                    operator = "-";
                    displayOp = "−";
                    break;
                default:
                    operator = op;
                    break;
            }
            
            updateSecondaryDisplay(firstNumber + " " + displayOp);
            currentNumber = "";
            isNewOperation = true;
        }
    }

    private void handleEqualsInput() {
        if (!firstNumber.isEmpty() && !currentNumber.isEmpty() && !operator.isEmpty()) {
            try {
                double num1 = Double.parseDouble(firstNumber);
                double num2 = Double.parseDouble(currentNumber);
                double result = 0;

                switch (operator) {
                    case "+":
                        result = num1 + num2;
                        break;
                    case "-":
                        result = num1 - num2;
                        break;
                    case "*":
                        result = num1 * num2;
                        break;
                    case "/":
                        if (num2 != 0) {
                            result = num1 / num2;
                        } else {
                            Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        break;
                }

                String resultString;
                if (result == (long) result) {
                    resultString = String.valueOf((long) result);
                } else {
                    resultString = String.valueOf(result);
                }

                currentNumber = resultString;
                updateDisplay(currentNumber);
                
                firstNumber = "";
                operator = "";
                isNewOperation = true;
                updateSecondaryDisplay("");

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid calculation", Toast.LENGTH_SHORT).show();
                handleClearInput();
            }
        }
    }

    private void handleClearInput() {
        currentNumber = "";
        firstNumber = "";
        operator = "";
        isNewOperation = true;
        updateDisplay("0");
        updateSecondaryDisplay("");
    }

    private void handleBackspaceInput() {
        if (!currentNumber.isEmpty() && !isNewOperation) {
            currentNumber = currentNumber.substring(0, currentNumber.length() - 1);
            if (currentNumber.isEmpty()) {
                updateDisplay("0");
                isNewOperation = true;
            } else {
                updateDisplay(currentNumber);
            }
        }
    }

    private void updateDisplay(String value) {
        if (value.isEmpty()) {
            tvDisplay.setText("0");
        } else {
            tvDisplay.setText(value);
        }
    }

    private void updateSecondaryDisplay(String value) {
        tvSecondaryDisplay.setText(value);
    }
}























