package com.example.practical_9;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private CheckBox[] checkBoxes;
    private String[] items = {"Milk", "Bread", "Eggs", "Cheese"};
    private TextView textViewSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkBoxes = new CheckBox[]{
            findViewById(R.id.checkBoxMilk),
            findViewById(R.id.checkBoxBread),
            findViewById(R.id.checkBoxEggs),
            findViewById(R.id.checkBoxCheese)
        };

        textViewSelected = findViewById(R.id.textViewSelected);

        for (CheckBox cb : checkBoxes) {
            cb.setOnCheckedChangeListener((v, c) -> updateSelectedItems());
        }
    }

    private void updateSelectedItems() {
        ArrayList<String> selected = new ArrayList<>();
        for (int i = 0; i < checkBoxes.length; i++) {
            if (checkBoxes[i].isChecked()) selected.add(items[i]);
        }

        if (selected.isEmpty()) {
            textViewSelected.setText("No items selected");
        } else {
            textViewSelected.setText("✓ " + String.join("\n✓ ", selected));
        }
    }
}